import { useState, useRef } from 'react';
import { QuoteData, CalculatedTotals, WorkshopProfile } from '../types';
import { formatBRL } from '../utils/formatters';
import { 
  downloadElementAsPdf, 
  canSharePdfFile, 
  shareOrSavePdfFile, 
  triggerBlobDownload 
} from '../utils/pdfGenerator';
import { hapticAudio } from '../utils/audioFeedback';
import { 
  Printer, 
  X, 
  Download, 
  ShieldCheck, 
  CheckCircle, 
  User, 
  Phone, 
  MapPin, 
  MessageCircle,
  Calendar,
  CreditCard,
  QrCode,
  Layers,
  Sparkles,
  FileCheck,
  Building2,
  Check,
  Eye,
  FileText,
  Smartphone,
  FileDown,
  Share2
} from 'lucide-react';

interface PrintProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
  quote: QuoteData;
  totals: CalculatedTotals;
  profile: WorkshopProfile;
  onShareWhatsApp?: () => void;
}

export function PrintProposalModal({
  isOpen,
  onClose,
  quote,
  totals,
  profile,
  onShareWhatsApp,
}: PrintProposalModalProps) {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfProgressText, setPdfProgressText] = useState('');
  const [pdfTheme, setPdfTheme] = useState<'app' | 'clean'>('app');
  const [showItemValues, setShowItemValues] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [generatedPdf, setGeneratedPdf] = useState<{
    blobUrl: string;
    file: File;
    fileName: string;
    sizeKb: number;
  } | null>(null);

  const documentRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePrint = () => {
    hapticAudio.playTap();
    window.print();
  };

  const handleThemeChange = (theme: 'app' | 'clean') => {
    setPdfTheme(theme);
    setGeneratedPdf(null); // Reset cached PDF to re-render with selected theme
  };

  const handleItemValuesChange = () => {
    setShowItemValues(!showItemValues);
    setGeneratedPdf(null); // Reset cached PDF to re-render
  };

  const handleDownloadPdf = async () => {
    if (isGeneratingPdf) return;

    // If PDF was already compiled and is ready, trigger immediate download
    if (generatedPdf) {
      hapticAudio.playTap();
      triggerBlobDownload(generatedPdf.blobUrl, generatedPdf.fileName);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
      return;
    }

    if (!documentRef.current) return;

    try {
      setIsGeneratingPdf(true);
      hapticAudio.playTap();
      setDownloadSuccess(false);

      const clientName = (quote.projectClient || 'cliente')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]/g, '_')
        .slice(0, 20);

      const quoteNum = quote.id.replace('quote_', '').slice(-6);
      const fileName = `Proposta_${clientName}_${quoteNum}.pdf`;

      const result = await downloadElementAsPdf(documentRef.current, {
        fileName,
        isDark: pdfTheme === 'app',
        onProgress: (step) => setPdfProgressText(step),
      });

      const sizeKb = Math.round(result.blob.size / 1024);
      setGeneratedPdf({
        blobUrl: result.blobUrl,
        file: result.file,
        fileName: result.fileName,
        sizeKb,
      });

      hapticAudio.playSuccess();
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 5000);
    } catch (err) {
      console.error('Falha ao baixar PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
      setPdfProgressText('');
    }
  };

  const handleMobileSaveOrShare = async () => {
    if (!generatedPdf) return;
    hapticAudio.playTap();
    const shared = await shareOrSavePdfFile(generatedPdf.file);
    if (shared) {
      hapticAudio.playSuccess();
    } else {
      triggerBlobDownload(generatedPdf.blobUrl, generatedPdf.fileName);
    }
  };

  // Format creation date
  const formattedDate = quote.date 
    ? new Date(quote.date).toLocaleDateString('pt-BR') 
    : new Date().toLocaleDateString('pt-BR');

  // Filter items with quantities
  const metals = (quote.metalItems || []).filter(i => i.quantity > 0);
  const materials = (quote.materialItems || []).filter(i => i.quantity > 0);
  const consumables = (quote.consumableItems || []).filter(i => i.quantity > 0);
  const discs = (quote.discItems || []).filter(i => i.quantity > 0);
  const labors = (quote.laborItems || []).filter(i => i.quantity > 0);
  const extras = (quote.extraCosts || []).filter(e => e.cost > 0);

  const isDarkAppTheme = pdfTheme === 'app';

  return (
    <div className="fixed inset-0 bg-zinc-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-zinc-900 text-zinc-100 rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-zinc-800 flex flex-col my-auto max-h-[96vh] print:max-h-none print:border-none print:shadow-none print:w-full print:rounded-none">
        
        {/* Modal Action Bar (Hidden during printing) */}
        <div className="bg-zinc-950 text-white p-3.5 px-4 sm:px-6 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0 print:hidden border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <span className="font-extrabold text-sm text-white tracking-tight block">
                Gerador de Proposta em PDF
              </span>
              <span className="text-[11px] text-zinc-400">
                Layout similar à interface da Serralheria Pro
              </span>
            </div>
          </div>

          {/* Quick Configuration Toggles */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-0.5 text-xs">
              <button
                type="button"
                onClick={() => handleThemeChange('app')}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                  isDarkAppTheme 
                    ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700' 
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Estilo App (Dark)
              </button>
              <button
                type="button"
                onClick={() => handleThemeChange('clean')}
                className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                  !isDarkAppTheme 
                    ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700' 
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Papel Limpo
              </button>
            </div>

            <button
              type="button"
              onClick={handleItemValuesChange}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition cursor-pointer flex items-center gap-1.5 ${
                showItemValues 
                  ? 'bg-red-950/40 text-red-300 border-red-800/50' 
                  : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
              }`}
              title="Exibir ou ocultar valores unitários dos itens no documento"
            >
              <Eye className="w-3 h-3" />
              <span>{showItemValues ? 'Preços Unit.: Sim' : 'Preços Unit.: Não'}</span>
            </button>
          </div>

          {/* Action Buttons: Download PDF, Print, Share, Close */}
          <div className="flex items-center gap-2">
            {onShareWhatsApp && (
              <button
                id="btn-modal-whatsapp"
                onClick={onShareWhatsApp}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                title="Enviar Proposta no WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-white/20 stroke-white" />
                <span className="hidden sm:inline">WhatsApp</span>
              </button>
            )}

            {/* Direct PDF Download Button */}
            <button
              id="btn-modal-download-pdf"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-red-600 via-red-600 to-red-700 hover:from-red-500 hover:to-red-600 active:scale-95 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-md shadow-red-950/30 border border-red-500/40 cursor-pointer"
              title="Baixar arquivo PDF no dispositivo"
            >
              {isGeneratingPdf ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Gerando...</span>
                </>
              ) : generatedPdf ? (
                <>
                  <FileDown className="w-3.5 h-3.5 text-white" />
                  <span>Baixar Novamente</span>
                </>
              ) : downloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-white" />
                  <span>Baixado!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-white" />
                  <span>Baixar PDF</span>
                </>
              )}
            </button>

            {/* Print Button */}
            <button
              id="btn-modal-print-native"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded-xl text-xs font-bold transition border border-zinc-700 cursor-pointer"
              title="Abrir diálogo de impressão do navegador"
            >
              <Printer className="w-3.5 h-3.5 text-zinc-300" />
              <span className="hidden sm:inline">Imprimir</span>
            </button>

            <button
              id="btn-modal-close"
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition cursor-pointer ml-1"
              title="Fechar visualização"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress Notification when generating */}
        {isGeneratingPdf && (
          <div className="bg-red-600/10 border-b border-red-500/20 px-4 sm:px-6 py-2.5 text-xs text-red-400 flex items-center justify-between animate-pulse">
            <span className="font-semibold">{pdfProgressText || 'Preparando documento PDF em alta resolução...'}</span>
            <span className="text-[10px] text-zinc-400">Por favor, aguarde alguns segundos</span>
          </div>
        )}

        {/* Success Alert & Ready to Save/Download on Device Bar */}
        {generatedPdf && !isGeneratingPdf && (
          <div className="bg-zinc-900 border-b border-zinc-800 px-4 sm:px-6 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                <FileCheck className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-xs sm:text-sm">
                    Arquivo PDF pronto para baixar
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold border border-emerald-500/30">
                    {generatedPdf.sizeKb} KB
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 font-mono block truncate max-w-[280px] sm:max-w-md">
                  {generatedPdf.fileName}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Direct Anchor Download: Guaranteed Native Download without any sandbox/iframe block */}
              <a
                id="btn-direct-download-anchor"
                href={generatedPdf.blobUrl}
                download={generatedPdf.fileName}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  hapticAudio.playSuccess();
                  setDownloadSuccess(true);
                  setTimeout(() => setDownloadSuccess(false), 4000);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                title="Salvar arquivo .pdf no armazenamento deste aparelho"
              >
                <Download className="w-3.5 h-3.5 text-white shrink-0" />
                <span>Salvar no Aparelho</span>
              </a>

              {/* Native Mobile Share / Save to Files */}
              {canSharePdfFile(generatedPdf.file) && (
                <button
                  id="btn-modal-share-device"
                  type="button"
                  onClick={handleMobileSaveOrShare}
                  className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded-xl text-xs font-bold transition border border-zinc-700 cursor-pointer"
                  title="Compartilhar / Salvar em Arquivos ou WhatsApp"
                >
                  <Smartphone className="w-3.5 h-3.5 text-red-400 shrink-0" />
                  <span>Celular / Compartilhar</span>
                </button>
              )}

              {/* View in Browser Tab */}
              <a
                id="btn-view-pdf-tab"
                href={generatedPdf.blobUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 px-3 py-2 bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-xl text-xs font-medium transition border border-zinc-700/80 cursor-pointer"
                title="Abrir arquivo PDF em nova aba do navegador"
              >
                <Eye className="w-3.5 h-3.5 text-zinc-400" />
                <span className="hidden sm:inline">Visualizar</span>
              </a>
            </div>
          </div>
        )}

        {/* Simple success notice if downloaded */}
        {downloadSuccess && !generatedPdf && (
          <div className="bg-emerald-600/10 border-b border-emerald-500/20 px-6 py-2 text-xs text-emerald-400 flex items-center gap-2">
            <CheckCircle className="w-3.5 h-3.5" />
            <span className="font-bold">PDF gerado e baixado com sucesso! Verifique a pasta de Downloads do seu aparelho.</span>
          </div>
        )}

        {/* Scrollable Document Container */}
        <div className="p-3 sm:p-6 overflow-y-auto bg-zinc-950 flex justify-center print:p-0 print:bg-white print:overflow-visible">
          
          {/* THE PROPOSAL DOCUMENT (Captured by html2canvas for PDF and printed by browser) */}
          <div
            ref={documentRef}
            id="proposal-document"
            className={`w-full max-w-[820px] rounded-2xl p-6 sm:p-8 md:p-10 space-y-6 shadow-xl transition-all print:p-4 print:shadow-none print:rounded-none print:w-full ${
              isDarkAppTheme
                ? 'bg-zinc-950 text-zinc-100 border border-zinc-800'
                : 'bg-white text-zinc-900 border border-zinc-200'
            }`}
            style={{ minHeight: '1080px' }}
          >
            {/* 1. DOCUMENT HEADER (Identical to the App's Master Header style) */}
            <div className={`p-5 rounded-2xl border transition-all ${
              isDarkAppTheme
                ? 'bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border-zinc-800 text-white shadow-md'
                : 'bg-zinc-50 border-zinc-300 text-zinc-900'
            }`}>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                {/* Workshop Identification & Logo */}
                <div className="flex items-start gap-3.5">
                  <div className="w-14 h-14 bg-black rounded-xl p-0.5 border border-zinc-700 shadow-md shrink-0 flex items-center justify-center overflow-hidden">
                    {profile.logoUrl ? (
                      <img
                        src={profile.logoUrl}
                        alt={profile.name || 'Logo'}
                        className="w-full h-full object-cover rounded-[10px]"
                        crossOrigin="anonymous"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-red-600 to-zinc-950 flex items-center justify-center text-white font-black text-lg">
                        {profile.name ? profile.name.slice(0, 2).toUpperCase() : 'LW'}
                      </div>
                    )}
                  </div>
                  <div>
                    <h1 className="text-xl sm:text-2xl font-black tracking-tight uppercase flex items-center gap-2">
                      <span>{profile.name || 'LW SERRALHERIA'}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-600/20 text-red-400 border border-red-500/30">
                        PRO
                      </span>
                    </h1>
                    <p className={`text-xs font-medium ${isDarkAppTheme ? 'text-zinc-400' : 'text-zinc-600'}`}>
                      {profile.description || 'Estruturas Metálicas • Esquadrias de Ferro • Portões, Grades e Coberturas'}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1 text-xs">
                      {profile.phone && (
                        <span className="flex items-center gap-1 font-semibold text-zinc-300">
                          <Phone className="w-3 h-3 text-red-500" />
                          <span>{profile.phone}</span>
                        </span>
                      )}
                      {profile.city && (
                        <span className="flex items-center gap-1 text-zinc-400">
                          <MapPin className="w-3 h-3 text-zinc-500" />
                          <span>{profile.city}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Proposal Number & Validity Badge */}
                <div className={`p-3 rounded-xl border text-left sm:text-right shrink-0 ${
                  isDarkAppTheme 
                    ? 'bg-zinc-900/90 border-zinc-800' 
                    : 'bg-white border-zinc-200 shadow-sm'
                }`}>
                  <span className="text-[10px] font-black text-red-500 uppercase tracking-widest block">
                    PROPOSTA COMERCIAL
                  </span>
                  <span className="text-sm font-black font-mono tracking-tight block">
                    Nº #{quote.id.replace('quote_', '').slice(-6).toUpperCase()}
                  </span>
                  <div className={`text-[11px] font-medium mt-0.5 space-y-0.5 ${isDarkAppTheme ? 'text-zinc-400' : 'text-zinc-600'}`}>
                    <div>Emissão: <strong>{formattedDate}</strong></div>
                    <div>Validade: <strong>{quote.validityDays || 15} dias</strong></div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. CLIENT & PROJECT DETAILS CARD */}
            <div className={`p-4 rounded-xl border grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs ${
              isDarkAppTheme 
                ? 'bg-zinc-900/60 border-zinc-800/80 text-zinc-300' 
                : 'bg-zinc-50 border-zinc-200 text-zinc-700'
            }`}>
              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-zinc-500 flex items-center gap-1">
                  <User className="w-3 h-3 text-red-500" />
                  Cliente / Solicitante:
                </span>
                <strong className="text-sm font-bold block text-zinc-100 dark:text-zinc-100">
                  {quote.projectClient || 'Cliente Não Informado'}
                </strong>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-zinc-500 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-red-500" />
                  Telefone / WhatsApp:
                </span>
                <strong className="text-sm font-bold block text-zinc-100 dark:text-zinc-100">
                  {quote.clientPhone || 'Não informado'}
                </strong>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-zinc-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-red-500" />
                  Local da Instalação / Obra:
                </span>
                <strong className="text-xs font-semibold block text-zinc-200 dark:text-zinc-200">
                  {quote.location || 'Oficina / A combinar'}
                </strong>
              </div>

              <div className="space-y-0.5">
                <span className="text-[10px] uppercase font-bold text-zinc-500 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-red-500" />
                  Prazo de Fabricação:
                </span>
                <strong className="text-xs font-semibold block text-zinc-200 dark:text-zinc-200">
                  {quote.deliveryDays ? `${quote.deliveryDays} dias` : '10 a 15 dias úteis'}
                </strong>
              </div>
            </div>

            {/* 3. TECHNICAL SPECIFICATIONS & MATERIALS (Matching App's Section Style) */}
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-1 border-b border-zinc-800">
                <h3 className="text-xs font-black uppercase tracking-wider text-red-500 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Especificações Técnicas e Relação de Itens</span>
                </h3>
                <span className="text-[10px] font-semibold text-zinc-500">
                  Materiais em Aço SAE 1020 / ASTM A36
                </span>
              </div>

              {/* SECTIONS TABLE */}
              <div className="overflow-hidden rounded-xl border border-zinc-800">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className={isDarkAppTheme ? 'bg-zinc-900 text-zinc-400 font-bold border-b border-zinc-800' : 'bg-zinc-100 text-zinc-700 font-bold border-b border-zinc-300'}>
                      <th className="py-2.5 px-3">Item / Especificação Técnica do Material</th>
                      <th className="py-2.5 px-3 text-center w-28">Qtd / Medida</th>
                      {showItemValues && <th className="py-2.5 px-3 text-right w-28">Subtotal</th>}
                    </tr>
                  </thead>
                  <tbody className={`divide-y ${isDarkAppTheme ? 'divide-zinc-800/60' : 'divide-zinc-200'}`}>
                    {/* Metal Items */}
                    {metals.map((m, idx) => (
                      <tr key={`metal-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                            <span>{m.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Perfil / Tubo de Aço</span>
                        </td>
                        <td className="py-2 px-3 text-center font-mono font-medium text-zinc-400">
                          {m.quantity} {m.unitLabel || 'm'}
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(m.quantity * m.unitCost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {/* Accessories & Materials */}
                    {materials.map((mat, idx) => (
                      <tr key={`mat-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-zinc-400 shrink-0" />
                            <span>{mat.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Acessório / Ferragem</span>
                        </td>
                        <td className="py-2 px-3 text-center font-mono font-medium text-zinc-400">
                          {mat.quantity} {mat.unitLabel || 'un'}
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(mat.quantity * mat.unitCost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {/* Consumables (Solda / Tinta) */}
                    {consumables.map((c, idx) => (
                      <tr key={`cons-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                            <span>{c.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Consumível de Solda / Proteção</span>
                        </td>
                        <td className="py-2 px-3 text-center font-mono font-medium text-zinc-400">
                          {c.quantity} {c.unitLabel || 'un'}
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(c.quantity * c.unitCost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {/* Discs & Abrasives */}
                    {discs.map((d, idx) => (
                      <tr key={`disc-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 shrink-0" />
                            <span>{d.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Disco & Abrasivo de Corte/Desbaste</span>
                        </td>
                        <td className="py-2 px-3 text-center font-mono font-medium text-zinc-400">
                          {d.quantity} {d.unitLabel || 'un'}
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(d.quantity * d.unitCost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {/* Labor */}
                    {labors.map((l, idx) => (
                      <tr key={`labor-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-600 shrink-0" />
                            <span>Mão de Obra Especializada: {l.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Corte, soldagem, esquadrejamento e montagem</span>
                        </td>
                        <td className="py-2 px-3 text-center font-medium text-emerald-400">
                          Incluso
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(l.quantity * l.unitCost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {/* Extra Costs */}
                    {extras.map((e, idx) => (
                      <tr key={`extra-${idx}`} className={isDarkAppTheme ? 'hover:bg-zinc-900/40' : 'hover:bg-zinc-50'}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                            <span>Logística & Serviços Adicionais: {e.description}</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 ml-3">Frete / Instalação / Despesas externas</span>
                        </td>
                        <td className="py-2 px-3 text-center font-medium text-emerald-400">
                          Incluso
                        </td>
                        {showItemValues && (
                          <td className="py-2 px-3 text-right font-mono text-zinc-300">
                            {formatBRL(e.cost)}
                          </td>
                        )}
                      </tr>
                    ))}

                    {metals.length === 0 && materials.length === 0 && labors.length === 0 && (
                      <tr>
                        <td colSpan={showItemValues ? 3 : 2} className="py-4 text-center text-zinc-500 italic">
                          Nenhum item adicionado a esta proposta.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 4. TECHNICAL OBSERVATIONS & FINISHES */}
            {quote.observations && (
              <div className={`p-4 rounded-xl border text-xs space-y-1 ${
                isDarkAppTheme ? 'bg-zinc-900/50 border-zinc-800 text-zinc-300' : 'bg-zinc-50 border-zinc-200 text-zinc-700'
              }`}>
                <span className="font-bold text-red-500 uppercase tracking-wider text-[11px] block">
                  Observações Técnicas, Acabamento & Instalação:
                </span>
                <p className="whitespace-pre-line leading-relaxed font-sans">
                  {quote.observations}
                </p>
              </div>
            )}

            {/* 5. COMMERCIAL SUMMARY & INVESTMENT (Exact replicate of App's Summary Card!) */}
            <div className={`rounded-2xl p-5 border-2 transition-all space-y-4 ${
              isDarkAppTheme 
                ? 'bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 border-red-500/60 text-white shadow-xl' 
                : 'bg-zinc-50 border-red-500/50 text-zinc-900'
            }`}>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-zinc-800">
                <div>
                  <span className="text-xs uppercase font-extrabold text-red-500 tracking-wider block">
                    Valor Total do Investimento
                  </span>
                  <span className="text-[11px] text-zinc-400">
                    Inclui materiais certificados, fabricação técnica e acabamentos
                  </span>
                </div>

                <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white dark:text-white">
                  {formatBRL(totals.finalPrice)}
                </div>
              </div>

              {/* 3 PAYMENT CONDITIONS CARDS (Identical to the App's Simulator) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                {/* Condition 1: PIX / Dinheiro com Desconto */}
                <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                  isDarkAppTheme 
                    ? 'bg-zinc-900/80 border-zinc-800' 
                    : 'bg-white border-zinc-200'
                }`}>
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold mb-1">
                      <span className="flex items-center gap-1 text-emerald-400">
                        <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                        À Vista (PIX)
                      </span>
                      {quote.cashDiscountPercent > 0 && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono">
                          -{quote.cashDiscountPercent}%
                        </span>
                      )}
                    </div>
                    <div className="text-lg font-black font-mono text-white dark:text-white my-0.5">
                      {formatBRL(totals.cashPrice)}
                    </div>
                  </div>
                  {totals.cashDiscountAmount > 0 && (
                    <div className="text-[10px] text-emerald-400 font-medium">
                      Economia de {formatBRL(totals.cashDiscountAmount)}
                    </div>
                  )}
                  {profile.pixKey && (
                    <div className="text-[10px] font-mono text-zinc-400 truncate mt-1 pt-1 border-t border-zinc-800">
                      Chave PIX: {profile.pixKey}
                    </div>
                  )}
                </div>

                {/* Condition 2: 50% Entrada + 50% Instalação */}
                <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                  isDarkAppTheme 
                    ? 'bg-zinc-900/80 border-zinc-800' 
                    : 'bg-white border-zinc-200'
                }`}>
                  <div>
                    <span className="text-xs font-bold text-zinc-200 block mb-1">
                      Condição Padrão (50/50)
                    </span>
                    <div className="text-xs space-y-1 text-zinc-400">
                      <div className="flex justify-between">
                        <span>Entrada (Sinal):</span>
                        <strong className="font-mono text-zinc-100">{formatBRL(totals.entryPrice)}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Na Entrega:</span>
                        <strong className="font-mono text-zinc-100">{formatBRL(totals.remainingPrice)}</strong>
                      </div>
                    </div>
                  </div>
                  <div className="text-[10px] text-zinc-500 font-medium mt-1">
                    Garante compra imediata do aço
                  </div>
                </div>

                {/* Condition 3: Cartão de Crédito */}
                <div className={`p-3 rounded-xl border flex flex-col justify-between ${
                  isDarkAppTheme 
                    ? 'bg-zinc-900/80 border-zinc-800' 
                    : 'bg-white border-zinc-200'
                }`}>
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold mb-1">
                      <span className="flex items-center gap-1 text-zinc-200">
                        <CreditCard className="w-3.5 h-3.5 text-red-500" />
                        Cartão de Crédito
                      </span>
                      <span className="text-[10px] font-mono text-zinc-400">
                        Até 12x
                      </span>
                    </div>
                    <div className="text-base font-black font-mono text-white my-0.5">
                      {totals.installmentCount || 3}x de {formatBRL(totals.installmentAmount)}
                    </div>
                  </div>
                  <div className="text-[10px] text-zinc-500 font-medium mt-1">
                    Consulte condições de parcelamento
                  </div>
                </div>
              </div>
            </div>

            {/* 6. WARRANTY & TERMS OF AGREEMENT */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs text-zinc-400">
              <div className="space-y-1">
                <span className="font-bold text-zinc-200 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Garantia & Termos do Serviço:
                </span>
                <p className="leading-relaxed">
                  {profile.warranty || 'Garantia legal de 90 dias contra defeitos de solda e fabricação estrutural. Não cobre danos por mau uso, agentes químicos corrosivos ou intempéries extraordinárias.'}
                </p>
              </div>

              <div className="space-y-1 sm:text-right">
                <span className="font-bold text-zinc-200 block">
                  Condições de Instalação:
                </span>
                <p className="leading-relaxed text-zinc-400">
                  O local da instalação deve apresentar vãos livres, nivelados e pontos de energia 220V/110V liberados para soldagem e testes mecânicos.
                </p>
              </div>
            </div>

            {/* 7. FORMAL SIGNATURE BOXES */}
            <div className="pt-6 border-t border-zinc-800/80 grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs">
              <div className="text-center sm:text-left">
                <div className="border-b border-zinc-700 w-56 mb-1.5"></div>
                <span className="font-bold text-zinc-200 block">
                  {profile.name || 'LW Serralheria'}
                </span>
                <span className="text-[11px] text-zinc-500">
                  Responsável Técnico / Serralheria
                </span>
              </div>

              <div className="text-center sm:text-right">
                <div className="border-b border-zinc-700 w-56 sm:ml-auto mb-1.5"></div>
                <span className="font-bold text-zinc-200 block">
                  {quote.projectClient || 'De Acordo / Assinatura do Cliente'}
                </span>
                <span className="text-[11px] text-zinc-500">
                  Aceite da Proposta Comercial • Data: ___/___/______
                </span>
              </div>
            </div>

            {/* 8. DOCUMENT WATERMARK / FOOTER */}
            <div className="pt-4 border-t border-zinc-800/50 flex flex-col sm:flex-row items-center justify-between text-[10px] text-zinc-500">
              <span>Documento gerado por LW Serralheria Pro • Sistema de Orçamentos Profissionais</span>
              <span>Proposta nº {quote.id.replace('quote_', '').slice(-6)} • {formattedDate}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
