import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export interface GeneratePdfOptions {
  fileName?: string;
  isDark?: boolean;
  onProgress?: (step: string) => void;
}

export interface GeneratedPdfResult {
  pdf: jsPDF;
  blob: Blob;
  blobUrl: string;
  file: File;
  fileName: string;
}

/**
 * Triggers a browser download of a Blob URL using an anchor element.
 * Compatible with mobile and desktop browsers.
 */
export function triggerBlobDownload(blobUrl: string, fileName: string): void {
  const link = document.createElement('a');
  link.href = blobUrl;
  link.setAttribute('download', fileName);
  link.setAttribute('target', '_blank');
  link.setAttribute('rel', 'noopener noreferrer');
  link.style.display = 'none';
  document.body.appendChild(link);
  
  link.click();
  
  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
  }, 3000);
}

/**
 * Checks if the current browser/device supports sharing or saving files natively.
 */
export function canSharePdfFile(file?: File): boolean {
  if (typeof navigator === 'undefined' || !navigator.share || !navigator.canShare) {
    return false;
  }
  if (file) {
    try {
      return navigator.canShare({ files: [file] });
    } catch {
      return false;
    }
  }
  return true;
}

/**
 * Shares or saves a PDF file to the mobile device (Arquivos / Downloads / WhatsApp / Drive).
 */
export async function shareOrSavePdfFile(file: File): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.share && navigator.canShare) {
    if (navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: file.name,
          text: 'Proposta Comercial em PDF gerada pela Serralheria Pro',
        });
        return true;
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          console.warn('Erro ao compartilhar/salvar arquivo:', err);
        }
      }
    }
  }
  return false;
}

/**
 * Captures an HTML element and generates a high-resolution PDF file matching A4 dimensions.
 * Returns the generated Blob, BlobURL, and File for direct device download or sharing.
 */
export async function downloadElementAsPdf(
  element: HTMLElement,
  options: GeneratePdfOptions = {}
): Promise<GeneratedPdfResult> {
  const fileName = options.fileName || 'proposta_serralheria.pdf';
  const isDark = options.isDark ?? false;
  const bgColor = isDark ? '#09090b' : '#ffffff';

  try {
    options.onProgress?.('Renderizando proposta em alta resolução...');

    // High DPI scale for crisp text, borders and badges
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: false,
      logging: false,
      backgroundColor: bgColor,
      windowWidth: element.scrollWidth || 1024,
      scrollX: 0,
      scrollY: 0,
    });

    options.onProgress?.('Compilando páginas do documento PDF...');

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pdfWidthMm = 210;
    const pdfHeightMm = 297;

    // Calculate canvas pixels corresponding to 1 A4 page
    const pageHeightInCanvasPx = Math.floor(canvas.width * (pdfHeightMm / pdfWidthMm));

    let sourceY = 0;
    let pageIndex = 0;

    while (sourceY < canvas.height) {
      if (pageIndex > 0) {
        pdf.addPage();
      }

      const currentSliceHeight = Math.min(pageHeightInCanvasPx, canvas.height - sourceY);

      // Create a dedicated canvas for each page to prevent rendering overlap
      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = pageHeightInCanvasPx;
      const pageCtx = pageCanvas.getContext('2d');

      if (pageCtx) {
        pageCtx.fillStyle = bgColor;
        pageCtx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);

        pageCtx.drawImage(
          canvas,
          0,
          sourceY,
          canvas.width,
          currentSliceHeight,
          0,
          0,
          canvas.width,
          currentSliceHeight
        );

        const pageImgData = pageCanvas.toDataURL('image/jpeg', 0.95);
        pdf.addImage(pageImgData, 'JPEG', 0, 0, pdfWidthMm, pdfHeightMm);
      }

      sourceY += pageHeightInCanvasPx;
      pageIndex++;
    }

    options.onProgress?.('Gerando arquivo final...');

    // Create raw Blob of application/pdf
    const pdfBlob = pdf.output('blob');
    const pdfFile = new File([pdfBlob], fileName, { type: 'application/pdf' });
    const blobUrl = URL.createObjectURL(pdfBlob);

    options.onProgress?.('Iniciando download para o aparelho...');

    // Trigger download directly via a DOM link
    triggerBlobDownload(blobUrl, fileName);

    return {
      pdf,
      blob: pdfBlob,
      blobUrl,
      file: pdfFile,
      fileName,
    };
  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    throw error;
  }
}
